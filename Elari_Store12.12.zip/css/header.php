<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
IncludeTemplateLangFile(__FILE__);

global $USER;
use Bitrix\Main\Page\Asset;

if (substr(PHP_OS, 0, 3) != "WIN") {
    if (!empty($_REQUEST['elari'])) {
        setcookie('elari','1',time()+86400,'/');
        header("Location: /");
        die();
    }

    if (empty($_COOKIE['elari'])) {
        die('403. Access denied =(');
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?$APPLICATION->ShowTitle(false);?></title>
    <?Asset::getInstance()->addString("<link rel='shortcut icon' type='image/x-icon' href='/favicon.ico' />");?>
    <?Asset::getInstance()->addCss(SITE_TEMPLATE_PATH."/css/bootstrap-reboot.min.css");?>
    <?Asset::getInstance()->addCss(SITE_TEMPLATE_PATH."/css/bootstrap.min.css");?>
    <?Asset::getInstance()->addCss(SITE_TEMPLATE_PATH."/fonts/fonts.css");?>
    <?Asset::getInstance()->addCss(SITE_TEMPLATE_PATH."/css/owl.carousel.min.css");?>
    <?Asset::getInstance()->addCss(SITE_TEMPLATE_PATH."/css/owl.theme.default.min.css");?>
    <?Asset::getInstance()->addCss(SITE_TEMPLATE_PATH."/css/style.css");?>
    <?Asset::getInstance()->addCss(SITE_TEMPLATE_PATH."/css/media.css");?>
    <?Asset::getInstance()->addString("<link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>");?>
    <?Asset::getInstance()->addCss(SITE_TEMPLATE_PATH."/css/animate.css");?>
    <?Asset::getInstance()->addCss(SITE_TEMPLATE_PATH."/css/glider.css");?>

    <?Asset::getInstance()->addJs(SITE_TEMPLATE_PATH."/js/jquery.min.js");?>
    <?Asset::getInstance()->addJs(SITE_TEMPLATE_PATH."/js/owl.carousel.js");?>
    <?Asset::getInstance()->addString('<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>')?>
    <?Asset::getInstance()->addJs(SITE_TEMPLATE_PATH."/js/bootstrap.min.js");?>
    <?Asset::getInstance()->addJs(SITE_TEMPLATE_PATH."/js/glider.js");?>
    <?Asset::getInstance()->addJs(SITE_TEMPLATE_PATH."/js/jquery.maskedinput.min.js");?>
    <?Asset::getInstance()->addJs(SITE_TEMPLATE_PATH."/js/lightgallery.js");?>
    <?Asset::getInstance()->addJs(SITE_TEMPLATE_PATH."/js/lightslider.js");?>
    <?Asset::getInstance()->addJs(SITE_TEMPLATE_PATH."/js/main.js");?>
    <?Asset::getInstance()->addJs(SITE_TEMPLATE_PATH."/js/video.js");?>
    <?Asset::getInstance()->addJs(SITE_TEMPLATE_PATH."/js/component.ext.js");?>
    <?Asset::getInstance()->addCss('/bitrix/css/main/bootstrap.css');?>
    <?CJSCore::Init(array("popup"));?>
    <?$APPLICATION->ShowHead();?>
</head>
<body class="<?$APPLICATION->ShowProperty('BODY_CLASS')?>">
<div class="modal"></div>
<?php
// фикс для фиксированной шапки и панели управления битрикса
$arGroupAvalaible = array( // массив групп, которые в которых нужно проверить доступность пользователя
    1, // администраторы
    7, // контент менеджер
    8, // менеджер интернет-магазина
);
$arGroups = CUser::GetUserGroup($USER->GetID()); // массив групп, в которых состоит пользователь
$result_intersect = array_intersect($arGroupAvalaible, $arGroups);// далее проверяем, если пользователь вошёл хотя бы в одну из групп, то позволяем ему что-либо делать
if(!empty($result_intersect)):?>
    <div id="adm_panel">
    <?$APPLICATION->ShowPanel();?>
    </div>
    <style>
        .fixed-top{top: 40px;}
        #adm_panel,#bx-panel,#admin-informer,.bx-core-popup-menu{z-index: 9999 !important;}
        body {margin-top:0px !important;}
    </style>
    <script>
        $(function(){
            $(window).scroll(function() {
                if (!$('#bx-panel').hasClass('bx-panel-fixed') && $(window).scrollTop() >= 40) {
                    $('.fixed-top').css('top', '0');
                    $('body').css('marginTop','47px');
                } else {
                    $('.fixed-top').css('top', '38px');
                    $('body').css('marginTop','0');
                }
            });
        });
    </script>
<?endif;?>
<?// if (!$USER->IsAuthorized()):?>
<!-- auth forms -->
<div class="container-fluid login-form-container">
    <div class="login-form-block">
        <div class="form-close"></div>

        <div class="links-form-block">
            <a href="#" class="login-in-link"><span id="login-in-link">Вход</span></a>
            <a href="#" class="registration-link"><span id="registration-link">Регистрация</span></a>
        </div>

        <?$APPLICATION->IncludeComponent(
            "bitrix:system.auth.form",
            "popup_auth",
            array(
                "FORGOT_PASSWORD_URL" => "",
                "PROFILE_URL" => "",
                "REGISTER_URL" => "",
                "SHOW_ERRORS" => "Y",
                "COMPONENT_TEMPLATE" => "popup_auth"
            ),
            false
        );?>

        <?$APPLICATION->IncludeComponent("bitrix:main.register", "popup_register", Array(
            "AUTH" => "Y",	// Автоматически авторизовать пользователей
            "REQUIRED_FIELDS" => array(	// Поля, обязательные для заполнения
                0 => "EMAIL",
            ),
            "SET_TITLE" => "N",	// Устанавливать заголовок страницы
            "SHOW_FIELDS" => array(	// Поля, которые показывать в форме
                0 => "EMAIL",
                1 => "NAME",
            ),
            "SUCCESS_PAGE" => "",	// Страница окончания регистрации
            "USER_PROPERTY" => "",	// Показывать доп. свойства
            "USER_PROPERTY_NAME" => "",	// Название блока пользовательских свойств
            "USE_BACKURL" => "Y",	// Отправлять пользователя по обратной ссылке, если она есть
        ),
            false
        );?>

        <?$APPLICATION->IncludeComponent("bitrix:main.auth.forgotpasswd", "forgotpasswd_popup", Array(
            "AUTH_AUTH_URL" => "/",	// Страница для авторизации
            "AUTH_REGISTER_URL" => "/",	// Страница для регистрации
        ),
            false
        );?>

    </div>
</div>
<!-- /auth forms -->
<?//endif;?>
<!-- header account block -->
<div class="account-block">
    <?if (!$USER->IsAuthorized()):?>
    <div class="out-account-block-links">
        <ul class="out-account-block-links">
            <li class="login"><span class="login-in">Войти</span></li>
            <li class="registration"><span class="create-an-account">Регистрация</span></li>
        </ul>
    </div>
    <?else:?>
    <div class="info-user">
        <div class="img-user"><img src="<?=SITE_TEMPLATE_PATH?>/img/noavatar.png" alt=""></div>
        <div class="contacts-user">
            <div class="name-user"><?=$USER->GetFullName()?></div>
            <div class="mail-user"><?=CUser::GetEmail()?></div>
        </div>
        <hr>
        <ul class="in-account-block-links">
            <li class="orders"><a href="/personal/orders/" title="">Заказы</a></li>
            <li class="settings"><a href="/personal/private/" title="">Настройки</a></li>
            <li class="exit"><a href="<?=$APPLICATION->GetCurPageParam("logout=yes", array("login","logout","register","forgot_password","change_password"));?>" title="">Выйти</a></li>
        </ul>
    </div>
    <?endif;?>
</div>
<!-- /header account block -->

<div class="container-fluid header-block fixed-top">
    <div class="row">
        <div class="col-12">
            <header>
                <nav class="navbar navbar-expand-lg navbar">
                    <div class="header">
                        <div class="menu-icon" data-behaviour="toggle-menu-icon">
                            <span class="menu-icon__bar"></span>
                        </div>
                    </div>
                    <nav class="nav" data-element="toggle-nav">
                        <ul class="nav__list">
                            <li class="nav__item catalog_header">
                                Каталог товаров:
                            </li>
                            <?$APPLICATION->IncludeComponent("bitrix:menu", "topMenu_mobile", Array(
                                "ALLOW_MULTI_SELECT" => "N",	// Разрешить несколько активных пунктов одновременно
                                "CHILD_MENU_TYPE" => "left",	// Тип меню для остальных уровней
                                "DELAY" => "N",	// Откладывать выполнение шаблона меню
                                "MAX_LEVEL" => "1",	// Уровень вложенности меню
                                "MENU_CACHE_GET_VARS" => array(	// Значимые переменные запроса
                                    0 => "",
                                ),
                                "MENU_CACHE_TIME" => "3600",	// Время кеширования (сек.)
                                "MENU_CACHE_TYPE" => "A",	// Тип кеширования
                                "MENU_CACHE_USE_GROUPS" => "Y",	// Учитывать права доступа
                                "ROOT_MENU_TYPE" => "top",	// Тип меню для первого уровня
                                "USE_EXT" => "N",	// Подключать файлы с именами вида .тип_меню.menu_ext.php
                            ),
                                false
                            );?>

                            <li class="nav__item">
                                <a class="nav__link nav__link--plus more_link" data-behaviour="toggle-link-icon" href="#">Еще</a>
                                <ul class="nav__sub-list" data-behaviour="toggle-sub-menu">
                                    <?$APPLICATION->IncludeComponent("bitrix:menu", "dropdownMenu_mobile", Array(
                                        "ALLOW_MULTI_SELECT" => "N",	// Разрешить несколько активных пунктов одновременно
                                        "CHILD_MENU_TYPE" => "left",	// Тип меню для остальных уровней
                                        "DELAY" => "N",	// Откладывать выполнение шаблона меню
                                        "MAX_LEVEL" => "1",	// Уровень вложенности меню
                                        "MENU_CACHE_GET_VARS" => array(	// Значимые переменные запроса
                                            0 => "",
                                        ),
                                        "MENU_CACHE_TIME" => "3600",	// Время кеширования (сек.)
                                        "MENU_CACHE_TYPE" => "A",	// Тип кеширования
                                        "MENU_CACHE_USE_GROUPS" => "Y",	// Учитывать права доступа
                                        "ROOT_MENU_TYPE" => "dropdown",	// Тип меню для первого уровня
                                        "USE_EXT" => "N",	// Подключать файлы с именами вида .тип_меню.menu_ext.php
                                    ),
                                        false
                                    );?>
                                </ul>
                            </li>
                        </ul>
                        <ul class="dop_links">
                            <?$APPLICATION->IncludeComponent("bitrix:menu", "additionalMenu_mobile", Array(
                                "ALLOW_MULTI_SELECT" => "N",	// Разрешить несколько активных пунктов одновременно
                                "CHILD_MENU_TYPE" => "left",	// Тип меню для остальных уровней
                                "DELAY" => "N",	// Откладывать выполнение шаблона меню
                                "MAX_LEVEL" => "1",	// Уровень вложенности меню
                                "MENU_CACHE_GET_VARS" => array(	// Значимые переменные запроса
                                    0 => "",
                                ),
                                "MENU_CACHE_TIME" => "3600",	// Время кеширования (сек.)
                                "MENU_CACHE_TYPE" => "A",	// Тип кеширования
                                "MENU_CACHE_USE_GROUPS" => "Y",	// Учитывать права доступа
                                "ROOT_MENU_TYPE" => "additional_mobile",	// Тип меню для первого уровня
                                "USE_EXT" => "N",	// Подключать файлы с именами вида .тип_меню.menu_ext.php
                            ),
                                false
                            );?>
                        </ul>
                        <div class="info">
                            <?$APPLICATION->IncludeComponent(
                                "bitrix:main.include",
                                "",
                                Array(
                                    "AREA_FILE_SHOW" => "file",
                                    "AREA_FILE_SUFFIX" => "inc",
                                    "EDIT_TEMPLATE" => "",
                                    "PATH" => "/local/templates/elari/include/mobileMenu_contacts.php"
                                )
                            );?>
                        </div>
                        <div class="social">
                            <?$APPLICATION->IncludeComponent(
                                "bitrix:main.include",
                                "",
                                Array(
                                    "AREA_FILE_SHOW" => "file",
                                    "AREA_FILE_SUFFIX" => "inc",
                                    "EDIT_TEMPLATE" => "",
                                    "PATH" => "/local/templates/elari/include/mobileMenu_social.php"
                                )
                            );?>
                        </div>
                    </nav>
                    <a class="navbar-brand" href="/"><img src="<?=SITE_TEMPLATE_PATH?>/img/logo.svg" alt="Logo ELARI" class="logo"/></a>
                    <div class="collapse navbar-collapse" id="navbarNavDropdown">
                        <ul class="navbar-nav navbar-nav-category">
                            <?$APPLICATION->IncludeComponent("bitrix:menu", "topMenu", Array(
                                "ALLOW_MULTI_SELECT" => "N",	// Разрешить несколько активных пунктов одновременно
                                "CHILD_MENU_TYPE" => "left",	// Тип меню для остальных уровней
                                "DELAY" => "N",	// Откладывать выполнение шаблона меню
                                "MAX_LEVEL" => "1",	// Уровень вложенности меню
                                "MENU_CACHE_GET_VARS" => array(	// Значимые переменные запроса
                                    0 => "",
                                ),
                                "MENU_CACHE_TIME" => "3600",	// Время кеширования (сек.)
                                "MENU_CACHE_TYPE" => "A",	// Тип кеширования
                                "MENU_CACHE_USE_GROUPS" => "Y",	// Учитывать права доступа
                                "ROOT_MENU_TYPE" => "top",	// Тип меню для первого уровня
                                "USE_EXT" => "N",	// Подключать файлы с именами вида .тип_меню.menu_ext.php
                            ),
                                false
                            );?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-exp anded="false">Ещё</a>
                                <div class="dropdown-menu animated fadeIn" aria-labelledby="navbarDropdownMenuLink">
                                    <?$APPLICATION->IncludeComponent("bitrix:menu", "dropdownMenu", Array(
                                        "ALLOW_MULTI_SELECT" => "N",	// Разрешить несколько активных пунктов одновременно
                                        "CHILD_MENU_TYPE" => "left",	// Тип меню для остальных уровней
                                        "DELAY" => "N",	// Откладывать выполнение шаблона меню
                                        "MAX_LEVEL" => "1",	// Уровень вложенности меню
                                        "MENU_CACHE_GET_VARS" => array(	// Значимые переменные запроса
                                            0 => "",
                                        ),
                                        "MENU_CACHE_TIME" => "3600",	// Время кеширования (сек.)
                                        "MENU_CACHE_TYPE" => "A",	// Тип кеширования
                                        "MENU_CACHE_USE_GROUPS" => "Y",	// Учитывать права доступа
                                        "ROOT_MENU_TYPE" => "dropdown",	// Тип меню для первого уровня
                                        "USE_EXT" => "N",	// Подключать файлы с именами вида .тип_меню.menu_ext.php
                                    ),
                                        false
                                    );?>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div class="nav-links-right">
                    <form action="" method="get" class="search">
                        <i class="fa fa-search fa-search_mobile"></i>
                        <input name="search" placeholder="Что вы ищете?" type="search" class="input_search search_mobile" autocomplete="off">
                    </form>
                    <?$APPLICATION->IncludeComponent("bitrix:menu", "topRightMenu", Array(
                        "ALLOW_MULTI_SELECT" => "N",	// Разрешить несколько активных пунктов одновременно
                        "CHILD_MENU_TYPE" => "left",	// Тип меню для остальных уровней
                        "DELAY" => "N",	// Откладывать выполнение шаблона меню
                        "MAX_LEVEL" => "1",	// Уровень вложенности меню
                        "MENU_CACHE_GET_VARS" => array(	// Значимые переменные запроса
                            0 => "",
                        ),
                        "MENU_CACHE_TIME" => "3600",	// Время кеширования (сек.)
                        "MENU_CACHE_TYPE" => "A",	// Тип кеширования
                        "MENU_CACHE_USE_GROUPS" => "Y",	// Учитывать права доступа
                        "ROOT_MENU_TYPE" => "top.right",	// Тип меню для первого уровня
                        "USE_EXT" => "N",	// Подключать файлы с именами вида .тип_меню.menu_ext.php
                    ),
                        false
                    );?>
                </div>
                <div class="header-items">
                    <?$APPLICATION->IncludeComponent("bitrix:sale.basket.basket.line", "header_basket", Array(
                        "HIDE_ON_BASKET_PAGES" => "Y",	// Не показывать на страницах корзины и оформления заказа
                        "PATH_TO_AUTHORIZE" => "",	// Страница авторизации
                        "PATH_TO_BASKET" => SITE_DIR."basket/",	// Страница корзины
                        "PATH_TO_ORDER" => SITE_DIR."personal/order/make/",	// Страница оформления заказа
                        "PATH_TO_PERSONAL" => SITE_DIR."personal/",	// Страница персонального раздела
                        "PATH_TO_PROFILE" => SITE_DIR."personal/",	// Страница профиля
                        "PATH_TO_REGISTER" => SITE_DIR."login/",	// Страница регистрации
                        "POSITION_FIXED" => "N",	// Отображать корзину поверх шаблона
                        "SHOW_AUTHOR" => "N",	// Добавить возможность авторизации
                        "SHOW_EMPTY_VALUES" => "Y",	// Выводить нулевые значения в пустой корзине
                        "SHOW_NUM_PRODUCTS" => "Y",	// Показывать количество товаров
                        "SHOW_PERSONAL_LINK" => "N",	// Отображать персональный раздел
                        "SHOW_PRODUCTS" => "N",	// Показывать список товаров
                        "SHOW_REGISTRATION" => "N",	// Добавить возможность регистрации
                        "SHOW_TOTAL_PRICE" => "N",	// Показывать общую сумму по товарам
                    ),
                        false
                    );?>
                    <div class="user-icon"></div><span class="user-profil-icon"></span>
                </div>
            </header>
        </div>
    </div>
</div>




	
						