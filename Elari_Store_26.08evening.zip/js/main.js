$(function () {
	$('[data-toggle="tooltip"]').tooltip();

	$('.fa-search').click(function(e){
		e.stopPropagation();
		$('.input_search').show();
		$('.nav-link-right').hide();
		$('.input_search').addClass('animated fadeInDown');
	});
	$('.input_search').click(function(e){
		e.stopPropagation();
	})
	$(document,'body').on('click',function(e){
		$('.input_search').hide();
		$('.nav-link-right').show();
	})
	$('.fa-search').click(function(e){
      $(".input_search").focus();
    });

    $('header .cart-icon').click(function(){
    	$('.shopping-cart-product-list').removeClass('animated fadeOutRight').addClass('animated fadeInRight').css('right', '5px');
	});
	$('.user-icon').click(function(){
		$('.account-block').removeClass('animated fadeOutRight').addClass('animated fadeInRight').css('right', '5px');
	});
	
	$('.login-in').click(function(){
		$('.login-form-container').addClass('animated fadeIn').css('display', 'block');
		$('.links-form-block').css('display', 'flex');
	    $('.login-form').css('display', 'block');
	    $('.registration-form').css('display', 'none');
		$('.recover-password-form').css('display', 'none')
		$('.registration-link').removeClass('active');
	    $('.login-in-link').addClass('active');
	    return false;
	});
	$('.create-an-account').click(function(){ 
		$('.login-form-container').addClass('animated fadeIn').css('display', 'block');
	    $('.registration-form').css('display', 'block');
	    $('.links-form-block').css('display', 'flex');
	    $('.login-form').css('display', 'none');
	    $('.recover-password-form').css('display', 'none')
	    $('.login-in-link').removeClass('active');
	    $('.registration-link').addClass('active');
	    return false;
	});
	$('#registration-link').click(function(){
		$('.registration-form').css('display', 'block');
		$('.links-form-block').css('display', 'flex');
		$('.login-form').css('display', 'none');
		$('.recover-password-form').css('display', 'none');
		$('.login-in-link').removeClass('active');
	    $('.registration-link').addClass('active');
	    return false;
	});
	$('#login-in-link').click(function(){
		$('.login-form').css('display', 'block');
		$('.links-form-block').css('display', 'flex');
		$('.registration-form').css('display', 'none');
		$('.recover-password-form').css('display', 'none');
	    $('.login-in-link').addClass('active');
	    $('.registration-link').removeClass('active');
	    return false;
	});

	$('#forgot-password-link').click(function(){
		$('.recover-password-form').css('display', 'block');
		$('.login-form').css('display', 'none');
		$('.registration-form').css('display', 'none');
		$('.links-form-block').css('display', 'none');
		return false;
	});
	 $('.form-close').click(function() {
	 	$('.login-form-container').removeClass('animated fadeOut').css('display', 'none'); 
	  });

	 $('.buy-btn').click(function(){
	 	$('.buy-window').removeClass('animated fadeOut');
		$('.buy-window').addClass('animated fadeInUpBig').css('right', '0');
		$('body').addClass('hidden');
		return false;
	});
	 $('.buy-window-close').click(function() {
	 	$('.buy-window').removeClass('animated fadeInUpBig').addClass('animated fadeOut'); 
	 	$('.buy-window').css('right', '-100vw');
	 	$('body').removeClass('hidden');
	 	return false;
	  });
	 $('.continue-shopping').click(function() {
	 	$('.buy-window').removeClass('animated fadeInUpBig').addClass('animated fadeOut'); 
	 	$('.buy-window').css('right', '-100vw');
	 	$('body').removeClass('hidden');
	 	return false;
	  });
});     


$(document).mouseup(function (e) {
    var container = $(".login-form-container");
    if (container.has(e.target).length === 0){
        $('.login-form-container').removeClass('fadeIn').css('display','none');
    }
});

 $(document).ready(function() {
  $(document).mouseup(function (e){ // событие клика по веб-документу
    var shoppingcart = $(".shopping-cart-product-list"); // тут указываем ID элемента
    if (!shoppingcart.is(e.target) // если клик был не по нашему блоку
      && shoppingcart.has(e.target).length === 0) { // и не по его дочерним элементам
      $('.shopping-cart-product-list').removeClass('animated fadeInRight').addClass('animated fadeOutRight');
    }
    var accountblock = $(".account-block"); // тут указываем ID элемента
    if (!accountblock.is(e.target) // если клик был не по нашему блоку
      && accountblock.has(e.target).length === 0) { // и не по его дочерним элементам
      $('.account-block').removeClass('animated fadeInRight').addClass('animated fadeOutRight');
    }
  });
  $('.minus').click(function () {
    var $input = $(this).parent().find('input');
    var count = parseInt($input.val()) - 1;
    count = count < 1 ? 1 : count;
    $input.val(count);
    $input.change();
    return false;
   });
   $('.plus').click(function () {
    var $input = $(this).parent().find('input');
    $input.val(parseInt($input.val()) + 1);
    $input.change();
    return false;
   });
});

  $('#promokod').keyup(function () {
        var pswd = $('#promokod').val();
        if ( pswd.length < 8 ) {
            $('.gray_bg_btn').removeClass('active').addClass('invalid');
        } else {
            $('.gray_bg_btn').removeClass('invalid').addClass('active');
        }
    })